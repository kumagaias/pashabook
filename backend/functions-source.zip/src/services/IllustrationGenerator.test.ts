import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { IllustrationGenerator } from './IllustrationGenerator';
import { StoryPage } from '../types/models';

// Mock the Google Cloud clients
vi.mock('@google-cloud/vertexai', () => ({
  VertexAI: vi.fn(() => ({
    getGenerativeModel: vi.fn(() => ({
      generateImages: vi.fn(),
    })),
  })),
}));

vi.mock('@google-cloud/storage', () => ({
  Storage: vi.fn(() => ({
    bucket: vi.fn(() => ({
      file: vi.fn(() => ({
        save: vi.fn(),
      })),
    })),
  })),
}));

describe('IllustrationGenerator', () => {
  let generator: IllustrationGenerator;
  let mockModel: any;
  let mockStorage: any;
  let mockFile: any;

  beforeEach(async () => {
    // Reset mocks
    vi.clearAllMocks();

    // Create mock file
    mockFile = {
      save: vi.fn().mockResolvedValue(undefined),
    };

    // Create mock storage
    mockStorage = {
      bucket: vi.fn(() => ({
        file: vi.fn(() => mockFile),
      })),
    };

    // Create mock model
    mockModel = {
      generateImages: vi.fn(),
    };

    // Mock the constructors
    const { VertexAI } = await import('@google-cloud/vertexai');
    const { Storage } = await import('@google-cloud/storage');
    
    vi.mocked(VertexAI).mockImplementation(() => ({
      getGenerativeModel: vi.fn(() => mockModel),
    }) as any);
    vi.mocked(Storage).mockImplementation(() => mockStorage);

    generator = new IllustrationGenerator();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('generateAll', () => {
    const createMockPages = (count: number): StoryPage[] => {
      return Array.from({ length: count }, (_, i) => ({
        pageNumber: i + 1,
        narrationText: `This is page ${i + 1} narration text with enough words to meet requirements.`,
        imagePrompt: `A colorful scene for page ${i + 1}`,
        animationMode: i === 2 ? ('highlight' as const) : ('standard' as const),
      }));
    };

    const mockStyle = 'Bright watercolor style with soft edges and vibrant colors';
    const mockCharacters = [
      { name: 'Luna', description: 'A small white rabbit with blue eyes' },
      { name: 'Max', description: 'A friendly brown bear wearing a red scarf' },
    ];

    beforeEach(() => {
      // Mock successful Imagen response
      const mockImageData = Buffer.from('mock-image-data');
      mockModel.generateImages.mockResolvedValue({
        images: [mockImageData],
      });
    });

    it('should generate illustrations for all pages in parallel', async () => {
      const pages = createMockPages(5);
      const jobId = 'test-job-123';

      const results = await generator.generateAll(pages, mockStyle, mockCharacters, jobId);

      // Verify all pages were processed
      expect(results).toHaveLength(5);
      expect(mockModel.generateImages).toHaveBeenCalledTimes(5);

      // Verify results are sorted by page number
      results.forEach((result, index) => {
        expect(result.pageNumber).toBe(index + 1);
        expect(result.imageUrl).toContain(`page-${index + 1}.jpg`);
        expect(result.width).toBe(1280);
        expect(result.height).toBe(720);
      });
    });

    it('should incorporate style description into prompts', async () => {
      const pages = createMockPages(2);
      const jobId = 'test-job-style';

      await generator.generateAll(pages, mockStyle, mockCharacters, jobId);

      // Verify style is included in all prompts
      expect(mockModel.generateImages).toHaveBeenCalledTimes(2);
      
      const calls = mockModel.generateImages.mock.calls;
      calls.forEach((call: any) => {
        const prompt = call[0].prompt;
        expect(prompt).toContain(mockStyle);
      });
    });

    it('should incorporate character descriptions into prompts', async () => {
      const pages = createMockPages(2);
      const jobId = 'test-job-chars';

      await generator.generateAll(pages, mockStyle, mockCharacters, jobId);

      // Verify characters are included in all prompts
      const calls = mockModel.generateImages.mock.calls;
      calls.forEach((call: any) => {
        const prompt = call[0].prompt;
        expect(prompt).toContain('Luna');
        expect(prompt).toContain('small white rabbit');
        expect(prompt).toContain('Max');
        expect(prompt).toContain('friendly brown bear');
      });
    });

    it('should generate illustrations at 1280x720 resolution', async () => {
      const pages = createMockPages(3);
      const jobId = 'test-job-resolution';

      const results = await generator.generateAll(pages, mockStyle, mockCharacters, jobId);

      // Verify all illustrations have correct dimensions
      results.forEach((result) => {
        expect(result.width).toBe(1280);
        expect(result.height).toBe(720);
      });

      // Verify Imagen was called with 16:9 aspect ratio
      const calls = mockModel.generateImages.mock.calls;
      calls.forEach((call: any) => {
        expect(call[0].aspect_ratio).toBe('16:9');
      });
    });

    it('should store images in Cloud Storage', async () => {
      const pages = createMockPages(2);
      const jobId = 'test-job-storage';

      await generator.generateAll(pages, mockStyle, mockCharacters, jobId);

      // Verify storage was called for each page
      expect(mockFile.save).toHaveBeenCalledTimes(2);
      
      // Verify correct content type
      expect(mockFile.save).toHaveBeenCalledWith(
        expect.any(Buffer),
        expect.objectContaining({
          metadata: expect.objectContaining({
            contentType: 'image/jpeg',
          }),
        })
      );
    });

    it('should update Job record with illustration URLs', async () => {
      const pages = createMockPages(3);
      const jobId = 'test-job-urls';

      const results = await generator.generateAll(pages, mockStyle, mockCharacters, jobId);

      // Verify URLs are in correct format
      results.forEach((result, index) => {
        expect(result.imageUrl).toMatch(
          new RegExp(`gs://.*jobs/${jobId}/illustrations/page-${index + 1}\\.jpg`)
        );
      });
    });

    it('should complete within 90 seconds timeout', async () => {
      const pages = createMockPages(6);
      const startTime = Date.now();

      await generator.generateAll(pages, mockStyle, mockCharacters, 'test-job');

      const elapsedTime = (Date.now() - startTime) / 1000;
      expect(elapsedTime).toBeLessThan(90);
    });

    it('should warn if generation exceeds timeout', async () => {
      const consoleSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
      const pages = createMockPages(3);

      // Mock Date.now to simulate timeout exceeded
      const startTime = Date.now();
      let callCount = 0;
      vi.spyOn(Date, 'now').mockImplementation(() => {
        callCount++;
        if (callCount === 1) {
          return startTime; // Start time
        }
        // Return time that exceeds timeout (91 seconds later)
        return startTime + 91000;
      });

      await generator.generateAll(pages, mockStyle, mockCharacters, 'test-job');

      expect(consoleSpy).toHaveBeenCalledWith(
        expect.stringContaining('exceeding 90s limit')
      );

      consoleSpy.mockRestore();
      vi.spyOn(Date, 'now').mockRestore();
    });

    it('should throw error if any page generation fails', async () => {
      const pages = createMockPages(3);

      // Make the second call fail
      mockModel.generateImages
        .mockResolvedValueOnce({ images: [Buffer.from('mock-image')] })
        .mockRejectedValueOnce(new Error('Imagen error'))
        .mockResolvedValueOnce({ images: [Buffer.from('mock-image')] });

      await expect(
        generator.generateAll(pages, mockStyle, mockCharacters, 'test-job')
      ).rejects.toThrow('Failed to generate illustrations');
    });

    it('should return illustrations sorted by page number', async () => {
      // Create pages in random order
      const pages: StoryPage[] = [
        { pageNumber: 3, narrationText: 'Page 3', imagePrompt: 'Prompt 3', animationMode: 'standard' },
        { pageNumber: 1, narrationText: 'Page 1', imagePrompt: 'Prompt 1', animationMode: 'standard' },
        { pageNumber: 2, narrationText: 'Page 2', imagePrompt: 'Prompt 2', animationMode: 'highlight' },
      ];

      const results = await generator.generateAll(pages, mockStyle, mockCharacters, 'test-job');

      // Verify results are sorted
      expect(results[0].pageNumber).toBe(1);
      expect(results[1].pageNumber).toBe(2);
      expect(results[2].pageNumber).toBe(3);
    });

    it('should handle empty images array from Imagen', async () => {
      const pages = createMockPages(1);
      mockModel.generateImages.mockResolvedValue({ images: [] });

      await expect(
        generator.generateAll(pages, mockStyle, mockCharacters, 'test-job')
      ).rejects.toThrow('No image generated from Imagen 3');
    });

    it('should handle null response from Imagen', async () => {
      const pages = createMockPages(1);
      mockModel.generateImages.mockResolvedValue(null);

      await expect(
        generator.generateAll(pages, mockStyle, mockCharacters, 'test-job')
      ).rejects.toThrow('No image generated from Imagen 3');
    });

    it('should throw error when Cloud Storage upload fails', async () => {
      const pages = createMockPages(1);
      mockFile.save.mockRejectedValue(new Error('Storage error'));

      await expect(
        generator.generateAll(pages, mockStyle, mockCharacters, 'test-job')
      ).rejects.toThrow('Failed to generate illustrations');
    });

    it('should use correct Imagen 3 parameters', async () => {
      const pages = createMockPages(1);

      await generator.generateAll(pages, mockStyle, mockCharacters, 'test-job');

      expect(mockModel.generateImages).toHaveBeenCalledWith(
        expect.objectContaining({
          number_of_images: 1,
          aspect_ratio: '16:9',
          safety_filter_level: 'block_some',
          person_generation: 'allow_adult',
        })
      );
    });

    it('should include children-appropriate context in prompts', async () => {
      const pages = createMockPages(1);

      await generator.generateAll(pages, mockStyle, mockCharacters, 'test-job');

      const call = mockModel.generateImages.mock.calls[0];
      const prompt = call[0].prompt;
      
      expect(prompt).toContain('children');
      expect(prompt).toContain('3-8 years');
      expect(prompt).toContain('storybook');
    });

    it('should store metadata with jobId and pageNumber', async () => {
      const pages = createMockPages(2);
      const jobId = 'test-job-metadata';

      await generator.generateAll(pages, mockStyle, mockCharacters, jobId);

      // Check metadata for each saved file
      const saveCalls = mockFile.save.mock.calls;
      saveCalls.forEach((call: any, index: number) => {
        const metadata = call[1].metadata.metadata;
        expect(metadata.jobId).toBe(jobId);
        expect(metadata.pageNumber).toBe((index + 1).toString());
      });
    });

    it('should handle base64 encoded image data', async () => {
      const pages = createMockPages(1);
      const base64Data = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
      
      mockModel.generateImages.mockResolvedValue({
        images: [base64Data],
      });

      await generator.generateAll(pages, mockStyle, mockCharacters, 'test-job');

      // Verify Buffer.from was called to convert base64
      expect(mockFile.save).toHaveBeenCalledWith(
        expect.any(Buffer),
        expect.any(Object)
      );
    });

    it('should handle Buffer image data directly', async () => {
      const pages = createMockPages(1);
      const bufferData = Buffer.from('mock-image-data');
      
      mockModel.generateImages.mockResolvedValue({
        images: [bufferData],
      });

      await generator.generateAll(pages, mockStyle, mockCharacters, 'test-job');

      // Verify Buffer was passed directly
      expect(mockFile.save).toHaveBeenCalledWith(
        bufferData,
        expect.any(Object)
      );
    });

    it('should generate unique file paths for each page', async () => {
      const pages = createMockPages(5);
      const jobId = 'test-job-paths';

      // Track file calls
      const fileCalls: string[] = [];
      mockStorage.bucket.mockReturnValue({
        file: vi.fn((path: string) => {
          fileCalls.push(path);
          return mockFile;
        }),
      });

      await generator.generateAll(pages, mockStyle, mockCharacters, jobId);

      // Verify all paths are unique
      const uniquePaths = new Set(fileCalls);
      expect(uniquePaths.size).toBe(5);

      // Verify path format
      fileCalls.forEach((path, index) => {
        expect(path).toBe(`jobs/${jobId}/illustrations/page-${index + 1}.jpg`);
      });
    });
  });
});
