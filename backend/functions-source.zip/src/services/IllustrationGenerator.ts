import { VertexAI } from '@google-cloud/vertexai';
import { Storage } from '@google-cloud/storage';
import { config } from '../config/gcp';
import { StoryPage, Illustration } from '../types/models';

export class IllustrationGenerator {
  private vertexAI: VertexAI;
  private model: any;
  private storage: Storage;
  private bucket: string;

  constructor() {
    this.vertexAI = new VertexAI({
      project: config.projectId,
      location: config.vertexAI.location,
    });
    
    this.model = this.vertexAI.getGenerativeModel({
      model: config.vertexAI.imagenModel,
    });
    
    this.storage = new Storage({
      projectId: config.projectId,
    });
    this.bucket = config.storageBucket;
  }

  /**
   * Generates illustrations for all story pages in parallel using Imagen 3
   * @param pages - Array of story pages with image prompts
   * @param style - Style description from image analysis
   * @param characters - Character descriptions from image analysis
   * @param jobId - Job ID for storage path
   * @returns Array of Illustration objects with image URLs
   */
  async generateAll(
    pages: StoryPage[],
    style: string,
    characters: Array<{ name: string; description: string }>,
    jobId: string
  ): Promise<Illustration[]> {
    const startTime = Date.now();

    try {
      // Generate all illustrations in parallel
      const illustrationPromises = pages.map((page) =>
        this.generateSingleIllustration(page, style, characters, jobId)
      );

      const illustrations = await Promise.all(illustrationPromises);

      // Validate completion time
      const elapsedTime = (Date.now() - startTime) / 1000;
      if (elapsedTime > config.timeouts.illustration) {
        console.warn(
          `Illustration generation took ${elapsedTime}s, exceeding ${config.timeouts.illustration}s limit`
        );
      }

      // Sort by page number to ensure correct order
      illustrations.sort((a, b) => a.pageNumber - b.pageNumber);

      return illustrations;
    } catch (error) {
      const elapsedTime = (Date.now() - startTime) / 1000;
      console.error(`Illustration generation failed after ${elapsedTime}s:`, error);
      throw new Error(
        `Failed to generate illustrations: ${error instanceof Error ? error.message : 'Unknown error'}`
      );
    }
  }

  /**
   * Generates a single illustration for a page
   */
  private async generateSingleIllustration(
    page: StoryPage,
    style: string,
    characters: Array<{ name: string; description: string }>,
    jobId: string
  ): Promise<Illustration> {
    try {
      // Build enhanced prompt with style and character descriptions
      const enhancedPrompt = this.buildEnhancedPrompt(page.imagePrompt, style, characters);

      // Create Imagen 3 request
      const request = {
        prompt: enhancedPrompt,
        number_of_images: 1,
        aspect_ratio: '16:9', // 1280x720 resolution
        safety_filter_level: 'block_some',
        person_generation: 'allow_adult',
      };

      // Generate image
      const response = await this.model.generateImages(request);

      if (!response || !response.images || response.images.length === 0) {
        throw new Error('No image generated from Imagen 3');
      }

      // Get the generated image data
      const imageData = response.images[0];
      
      // Upload to Cloud Storage
      const fileName = `jobs/${jobId}/illustrations/page-${page.pageNumber}.jpg`;
      const file = this.storage.bucket(this.bucket).file(fileName);

      // Convert base64 to buffer if needed
      const imageBuffer = Buffer.isBuffer(imageData)
        ? imageData
        : Buffer.from(imageData, 'base64');

      await file.save(imageBuffer, {
        metadata: {
          contentType: 'image/jpeg',
          metadata: {
            jobId,
            pageNumber: page.pageNumber.toString(),
          },
        },
      });

      const imageUrl = `gs://${this.bucket}/${fileName}`;

      return {
        pageNumber: page.pageNumber,
        imageUrl,
        width: 1280,
        height: 720,
      };
    } catch (error) {
      console.error(`Failed to generate illustration for page ${page.pageNumber}:`, error);
      throw new Error(
        `Failed to generate illustration for page ${page.pageNumber}: ${
          error instanceof Error ? error.message : 'Unknown error'
        }`
      );
    }
  }

  /**
   * Builds an enhanced prompt incorporating style and character descriptions
   */
  private buildEnhancedPrompt(
    basePrompt: string,
    style: string,
    characters: Array<{ name: string; description: string }>
  ): string {
    // Build character descriptions section
    const characterDescriptions = characters
      .map((char) => `${char.name}: ${char.description}`)
      .join('. ');

    // Combine all elements into a comprehensive prompt
    const enhancedPrompt = `${basePrompt}

Style: ${style}

Characters: ${characterDescriptions}

Create a children's storybook illustration in the specified style with consistent character appearances. The image should be colorful, engaging, and appropriate for children aged 3-8 years. Resolution: 1280x720 pixels.`;

    return enhancedPrompt;
  }
}
